#!/bin/bash

java -cp ".;./supportlibraries/External_Jars/*" allocator.Allocator