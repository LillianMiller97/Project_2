package pageObjects;

import org.openqa.selenium.By;

/**
 * UI Map for UserRegistrationConfirmationPage 
 */
public class UserRegistrationConfirmationPage {
	// Links
	public static final By lnkSignIn = By.linkText("sign-in");
}